lz-string-php boilerplate
=========================

HTML Boilerplate to test the php implementiation of lz-string manually 

## Usage
```cmd
php -S localhost:8000
```
